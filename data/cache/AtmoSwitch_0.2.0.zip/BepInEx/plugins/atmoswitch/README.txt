# AtmoSwitch
This mod allows you to switch vessels while moving within the atmosphere.

## Compatibility
Tested with Kerbal Space Program 2 v0.1.0.0.20892

## Install
1. Download and install [SpaceWarp](https://spacedock.info/mod/3257/Space%20Warp)
2. Download and extract this mod into your KSP 2 install folder (usually "Kerbal Space Program 2")
