A collection of bug fixes for KSP2.

Current Bug Fixes

1. Prevent ships from getting stuck in a "Landed" state while flying. This bug prevents you from seeing your ship's trajectory in the map view.

Install

1. Download and install BepInEx 5
2. Download and extract this mod into your KSP 2 install folder (usually "Kerbal Space Program 2")

