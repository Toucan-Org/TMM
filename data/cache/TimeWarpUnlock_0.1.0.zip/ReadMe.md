This mod makes all warp speeds available for selection at all times.

Install

1. Download and install BepInEx 5
2. Download and extract this mod into your KSP 2 install folder (usually "Kerbal Space Program 2")

